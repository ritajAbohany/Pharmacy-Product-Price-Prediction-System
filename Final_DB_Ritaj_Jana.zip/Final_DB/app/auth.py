import hashlib

def hash_password(password: str) -> str:
    """
    Implements the exact flow:
    - Hash password
    - Store hashed password
    - On login: hash input password and match directly in DB query
    """
    return hashlib.sha256(password.encode("utf-8")).hexdigest()