import os
from pymongo import MongoClient

MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://finalprojectuser:2GlssgBVL0sB65uI@final-project-cluster.0kkgxgo.mongodb.net/")

client = MongoClient(MONGO_URI)

# database name
db = client["pharmacyDB"]

# collections' names
users_collection = db["users"]
data_collection = db["data"]
models_collection = db["models"]
predictions_collection = db["predictions"]