from fastapi import FastAPI, Request, Form
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.status import HTTP_303_SEE_OTHER
from fastapi.templating import Jinja2Templates
from io import BytesIO
import pandas as pd
import numpy as np
import joblib
import gridfs
from datetime import datetime, timezone

from app.database import users_collection, models_collection, predictions_collection, db
from app.auth import hash_password


app = FastAPI()

SESSION_SECRET = "CHANGE_ME_TO_A_RANDOM_SECRET"
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.mount("/outputs", StaticFiles(directory="app/outputs"), name="outputs")
templates = Jinja2Templates(directory="app/templates")

_ml_model = None

def load_model_from_mongo():
    """
    Load the active ML model from pharmacyDB using GridFS.
    Expects a document with _id='active' in models collection with gridfs_id reference.
    """
    global _ml_model
    if _ml_model is not None:
        return _ml_model

    # Get model metadata
    doc = models_collection.find_one({"_id": "active"})
    if not doc:
        raise RuntimeError("No active model found in pharmacyDB.models with _id='active'.")

    # Load from GridFS
    fs = gridfs.GridFS(db, collection="model_files")
    gridfs_file = fs.find_one({"filename": "active_pipeline.joblib"})
    if not gridfs_file:
        raise RuntimeError("No pipeline found in GridFS with filename 'active_pipeline.joblib'.")

    raw_bytes = gridfs_file.read()
    _ml_model = joblib.load(BytesIO(raw_bytes))
    return _ml_model


@app.get("/", response_class=HTMLResponse)
def root():
    return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)


@app.get("/signup", response_class=HTMLResponse)
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request, "error": None})


@app.post("/signup", response_class=HTMLResponse)
def signup_submit(
    request: Request,
    first_name: str = Form(...),
    last_name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    telephone: str = Form(...),
    agree: str = Form(...),
):
    normalized_email = email.strip().lower()

    existing = users_collection.find_one({"email": normalized_email})
    if existing:
        return templates.TemplateResponse(
            "signup.html",
            {"request": request, "error": "This email is already registered. Please login."},
            status_code=400,
        )

    user_doc = {
        "first_name": first_name.strip(),
        "last_name": last_name.strip(),
        "email": normalized_email,
        "password": hash_password(password),
        "telephone": telephone.strip(),
        "agree": True,
    }

    users_collection.insert_one(user_doc)

    request.session["user_email"] = normalized_email
    request.session["remember_me"] = False

    return RedirectResponse(url="/ai-insights", status_code=HTTP_303_SEE_OTHER)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@app.post("/login", response_class=HTMLResponse)
def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    remember: str = Form(...),
):
    normalized_email = email.strip().lower()
    hashed = hash_password(password)

    user = users_collection.find_one({"email": normalized_email, "password": hashed})
    if not user:
        return templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "Invalid email or password."},
            status_code=401,
        )

    request.session["user_email"] = normalized_email
    request.session["remember_me"] = True

    return RedirectResponse(url="/ai-insights", status_code=HTTP_303_SEE_OTHER)


@app.get("/profile", response_class=HTMLResponse)
def profile_page(request: Request):
    user_email = request.session.get("user_email")
    if not user_email:
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    user = users_collection.find_one({"email": user_email}, {"password": 0})
    if not user:
        request.session.clear()
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    return templates.TemplateResponse("profile.html", {"request": request, "user": user})


@app.get("/report", response_class=HTMLResponse)
def report_page(request: Request):
    user_email = request.session.get("user_email")
    if not user_email:
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    # the report is served statically from /outputs/...
    return templates.TemplateResponse(
        "report.html",
        {"request": request, "report_url": "/outputs/stakeholder_report.html"},
    )


@app.get("/ai-insights", response_class=HTMLResponse)
def ai_insights_page(request: Request):
    user_email = request.session.get("user_email")
    if not user_email:
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    return templates.TemplateResponse(
        "ai_insights.html",
        {"request": request, "error": None, "prediction": None}
    )


@app.post("/ai-insights", response_class=HTMLResponse)
def ai_insights_submit(
    request: Request,
    name: str = Form(...),
    packaging: str = Form(...),
    price: float = Form(...),
    pack_count: float = Form(...),
    pack_quantity: float = Form(...),
    pack_unit: str = Form(...),
    discount_pct: float = Form(...),
    has_discount: int = Form(...),
    category: str = Form(...),
):
    user_email = request.session.get("user_email")
    if not user_email:
        return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)

    try:
        ml_model = load_model_from_mongo()

        # Calculate derived fields
        price_per_unit = price / pack_quantity if pack_quantity > 0 else 0

        # Must match training column names exactly
        payload = {
            "name": name,
            "packaging": packaging,
            "price": float(price),
            "pack_count": float(pack_count),
            "pack_quantity": float(pack_quantity),
            "pack_unit": pack_unit,
            "discount_pct": float(discount_pct),
            "has_discount": int(has_discount),
            "category": category,
            "price_per_unit": float(price_per_unit),
        }

        X_new = pd.DataFrame([payload])
        pred = ml_model.predict(X_new)

        # Round to 2 decimal places for price
        prediction_value = round(float(pred[0]), 2)

        predictions_collection.insert_one({
            "user_email": user_email,
            "source": "html",
            "inputs": payload,
            "prediction": {
                "discounted_price": prediction_value
            },
            "created_at": datetime.now(timezone.utc)
        })

        return templates.TemplateResponse(
            "ai_insights.html",
            {"request": request, "error": None, "prediction": prediction_value},
        )

    except Exception as e:
        return templates.TemplateResponse(
            "ai_insights.html",
            {"request": request, "error": str(e), "prediction": None},
            status_code=500,
        )


# ---------------------------
# LOGOUT (button on profile)
# ---------------------------
@app.post("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/login", status_code=HTTP_303_SEE_OTHER)


# -----------------------------------
# DELETE ACCOUNT (button on profile)
# -----------------------------------
@app.post("/delete-account")
def delete_account(request: Request):
    user_email = request.session.get("user_email")
    if user_email:
        users_collection.delete_one({"email": user_email})
        predictions_collection.delete_many({"user_email": user_email}) # bonus
    request.session.clear()
    return RedirectResponse(url="/signup", status_code=HTTP_303_SEE_OTHER)