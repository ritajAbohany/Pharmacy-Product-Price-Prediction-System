# Elecventory Auth App (FastAPI + MongoDB)

## Run MongoDB
- Local MongoDB default: mongodb://localhost:27017
- Or set:
  - Windows (PowerShell): $env:MONGO_URI="mongodb+srv://..."
  - Linux/Mac: export MONGO_URI="mongodb+srv://..."

## Install
pip install -r app\requirements.txt

## Run
uvicorn app.main:app --reload

## Pages
- http://127.0.0.1:8000/signup
- http://127.0.0.1:8000/login
- http://127.0.0.1:8000/profile
- http://127.0.0.1:8000/ai-insights
- http://127.0.0.1:8000/report

