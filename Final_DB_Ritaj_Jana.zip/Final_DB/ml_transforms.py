# ml_transforms.py
import numpy as np

def apply_conditional_transforms_array(X, *, num_idx: dict, transform_map: dict):
    """
    X is a numpy array with columns in the same order as num_cols.
    Applies per-column transform using transform_map and column index map.
    """
    X = X.astype(float, copy=True)

    for c, t in transform_map.items():
        j = num_idx.get(c, None)
        if j is None or t == "none":
            continue

        col = X[:, j]

        if np.isnan(col).all():
            continue

        min_val = np.nanmin(col)
        if min_val < 0:
            col = col - min_val

        if t == "sqrt":
            X[:, j] = np.sqrt(col)
        elif t == "log1p":
            X[:, j] = np.log1p(col)

    return X
