"""
MongoDB -> Pandas -> 4 stakeholder-ready aggregations + 4 visualizations + HTML report.

Pharmacy Products Report - Analyzes pharmacy product data including:
- Pricing analysis (regular vs discounted)
- Category performance
- Discount distribution
- Pack unit analysis

Requirements:
  pip install pymongo pandas matplotlib numpy

Run for example:
  python mongo_report.py --mongo-uri "mongodb+srv://finalprojectuser:2GlssgBVL0sB65uI@final-project-cluster.0kkgxgo.mongodb.net/?appName=final-project-cluster" --db-name pharmacyDB --collection-name data --out-dir app/outputs
"""

from __future__ import annotations

import os
import argparse
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pymongo import MongoClient


# =========================
# ARGUMENTS
# =========================
def parse_args():
    p = argparse.ArgumentParser(description="MongoDB reporting pipeline (plots + HTML report)")
    p.add_argument("--mongo-uri", required=True, help="MongoDB connection URI")
    p.add_argument("--db-name", required=True, help="MongoDB database name")
    p.add_argument("--collection-name", required=True, help="MongoDB collection name")
    p.add_argument("--out-dir", default="outputs", help="Output directory")
    return p.parse_args()


# =========================
# LOAD DATA
# =========================
def load_collection_as_df(mongo_uri: str, db_name: str, coll_name: str) -> pd.DataFrame:
    client = MongoClient(mongo_uri)
    coll = client[db_name][coll_name]
    docs = list(coll.find({}, {"_id": 0}))
    if not docs:
        raise ValueError("No documents found in the collection. Check db/collection names.")
    return pd.DataFrame(docs)


def coerce_types(df: pd.DataFrame) -> pd.DataFrame:
    """Coerce pharmacy data columns to appropriate types."""
    numeric_cols = [
        "price",
        "discounted_price",
        "discount_percentage",
        "pack_count",
        "pack_quantity",
        "discount_pct",
        "has_discount",
        "price_per_unit",
        "discounted_price_per_unit",
    ]
    for c in numeric_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    for c in ["name", "packaging", "pack_unit", "category"]:
        if c in df.columns:
            df[c] = df[c].astype(str).replace({"nan": np.nan, "None": np.nan}).str.strip()

    return df


# =========================
# AGGREGATIONS (4) - Pharmacy Data
# =========================
def build_aggregations(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Build aggregations for pharmacy product data."""
    
    # 1) Executive KPI snapshot
    total_products = len(df)
    avg_price = df.get("price", pd.Series(dtype=float)).mean(skipna=True)
    avg_discounted_price = df.get("discounted_price", pd.Series(dtype=float)).mean(skipna=True)
    avg_discount_pct = df.get("discount_pct", pd.Series(dtype=float)).mean(skipna=True)
    products_with_discount = df.get("has_discount", pd.Series(dtype=float)).sum(skipna=True)
    discount_rate = (products_with_discount / total_products * 100) if total_products > 0 else 0
    distinct_categories = df.get("category", pd.Series(dtype=object)).nunique(dropna=True)
    total_savings = (df.get("price", pd.Series(dtype=float)).sum(skipna=True) - 
                     df.get("discounted_price", pd.Series(dtype=float)).sum(skipna=True))
    
    kpis = pd.DataFrame({
        "Metric": [
            "Total Products (SKUs)",
            "Average Price (EGP)",
            "Average Discounted Price (EGP)",
            "Average Discount (%)",
            "Products with Discount",
            "Discount Rate (%)",
            "Distinct Categories",
            "Total Potential Savings (EGP)",
        ],
        "Value": [
            total_products,
            avg_price,
            avg_discounted_price,
            avg_discount_pct,
            products_with_discount,
            discount_rate,
            distinct_categories,
            total_savings,
        ],
    })

    # 2) Top categories by product count and pricing
    if "category" in df.columns:
        category_stats = (
            df.groupby("category", dropna=True, as_index=False)
            .agg(
                product_count=("name", "count"),
                avg_price=("price", "mean"),
                avg_discounted_price=("discounted_price", "mean"),
                avg_discount_pct=("discount_pct", "mean"),
                products_with_discount=("has_discount", "sum"),
            )
            .sort_values("product_count", ascending=False)
        )
        total_products_check = category_stats["product_count"].sum()
        category_stats["share_pct"] = np.where(
            total_products_check > 0, 
            category_stats["product_count"] / total_products_check * 100, 
            np.nan
        )
    else:
        category_stats = pd.DataFrame(columns=["category", "product_count", "avg_price", "avg_discounted_price", "avg_discount_pct", "products_with_discount", "share_pct"])

    # 3) Pack unit analysis
    if "pack_unit" in df.columns:
        pack_unit_stats = (
            df.groupby("pack_unit", dropna=True, as_index=False)
            .agg(
                product_count=("name", "count"),
                avg_price=("price", "mean"),
                avg_price_per_unit=("price_per_unit", "mean"),
            )
            .sort_values("product_count", ascending=False)
        )
    else:
        pack_unit_stats = pd.DataFrame(columns=["pack_unit", "product_count", "avg_price", "avg_price_per_unit"])

    # 4) Discount analysis summary
    discounted = df[df.get("has_discount", pd.Series(dtype=float)) == 1] if "has_discount" in df.columns else pd.DataFrame()
    non_discounted = df[df.get("has_discount", pd.Series(dtype=float)) == 0] if "has_discount" in df.columns else pd.DataFrame()
    
    discount_summary = pd.DataFrame({
        "Metric": [
            "Products WITH discount",
            "Products WITHOUT discount",
            "Avg price (discounted products)",
            "Avg price (non-discounted products)",
            "Avg discount % (discounted only)",
            "Max discount %",
            "Min discount % (non-zero)",
        ],
        "Value": [
            len(discounted),
            len(non_discounted),
            discounted["price"].mean() if len(discounted) > 0 else np.nan,
            non_discounted["price"].mean() if len(non_discounted) > 0 else np.nan,
            discounted["discount_pct"].mean() if len(discounted) > 0 else np.nan,
            df["discount_pct"].max() if "discount_pct" in df.columns else np.nan,
            df[df["discount_pct"] > 0]["discount_pct"].min() if "discount_pct" in df.columns and (df["discount_pct"] > 0).any() else np.nan,
        ],
    })

    # Top discounted products
    if "discount_pct" in df.columns:
        keep_cols = [c for c in ["name", "category", "price", "discounted_price", "discount_pct"] if c in df.columns]
        top_discounted = df[df["discount_pct"] > 0][keep_cols].sort_values("discount_pct", ascending=False).head(15)
    else:
        top_discounted = pd.DataFrame()

    return {
        "kpis": kpis,
        "category_stats": category_stats,
        "pack_unit_stats": pack_unit_stats,
        "discount_summary": discount_summary,
        "top_discounted": top_discounted,
        "df_for_plots": df,
    }


# =========================
# VISUALIZATIONS (4) - Pharmacy Data
# =========================
def save_plots(df: pd.DataFrame, category_stats: pd.DataFrame, pack_unit_stats: pd.DataFrame, out_dir: str) -> dict[str, str]:
    """Generate 4 visualizations for pharmacy data."""
    os.makedirs(out_dir, exist_ok=True)
    paths: dict[str, str] = {}

    # 1) BAR: Top 10 categories by product count
    if len(category_stats) > 0 and "category" in category_stats.columns and "product_count" in category_stats.columns:
        top = category_stats.head(10).copy()
        plt.figure(figsize=(10, 6))
        bars = plt.bar(top["category"].astype(str), top["product_count"], color='steelblue')
        plt.xticks(rotation=45, ha="right")
        plt.title("Top 10 Categories by Product Count")
        plt.ylabel("Number of Products")
        plt.xlabel("Category")
        # Add value labels on bars
        for bar, val in zip(bars, top["product_count"]):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5, 
                    f'{int(val)}', ha='center', va='bottom', fontsize=9)
        plt.tight_layout()
        p1 = os.path.join(out_dir, "plot_1_top_categories_bar.png")
        plt.savefig(p1, dpi=200)
        plt.close()
        paths["bar_top_categories"] = p1

    # 2) BAR: Average price by category (top 10)
    if len(category_stats) > 0 and "avg_price" in category_stats.columns:
        top = category_stats.head(10).copy()
        plt.figure(figsize=(10, 6))
        x = np.arange(len(top))
        width = 0.35
        bars1 = plt.bar(x - width/2, top["avg_price"], width, label='Avg Price', color='coral')
        bars2 = plt.bar(x + width/2, top["avg_discounted_price"], width, label='Avg Discounted Price', color='teal')
        plt.xticks(x, top["category"].astype(str), rotation=45, ha="right")
        plt.title("Average Price vs Discounted Price by Category")
        plt.ylabel("Price (EGP)")
        plt.xlabel("Category")
        plt.legend()
        plt.tight_layout()
        p2 = os.path.join(out_dir, "plot_2_price_comparison_bar.png")
        plt.savefig(p2, dpi=200)
        plt.close()
        paths["bar_price_comparison"] = p2

    # 3) PIE: Products with vs without discount
    if "has_discount" in df.columns:
        with_discount = (df["has_discount"] == 1).sum()
        without_discount = (df["has_discount"] == 0).sum()
        if with_discount + without_discount > 0:
            labels = ["With Discount", "Without Discount"]
            values = [with_discount, without_discount]
            colors = ['#66b3ff', '#ff9999']
            explode = (0.05, 0)
            
            plt.figure(figsize=(8, 8))
            plt.pie(values, labels=labels, autopct=lambda p: f'{p:.1f}%\n({int(p*sum(values)/100)})', 
                   colors=colors, explode=explode, startangle=90)
            plt.title("Products: With vs Without Discount")
            plt.tight_layout()
            p3 = os.path.join(out_dir, "plot_3_discount_distribution_pie.png")
            plt.savefig(p3, dpi=200)
            plt.close()
            paths["pie_discount_distribution"] = p3

    # 4) HISTOGRAM: Price distribution
    if "price" in df.columns:
        prices = df["price"].dropna()
        if len(prices) > 0:
            plt.figure(figsize=(10, 6))
            plt.hist(prices, bins=50, color='mediumseagreen', edgecolor='black', alpha=0.7)
            plt.axvline(prices.mean(), color='red', linestyle='dashed', linewidth=2, label=f'Mean: {prices.mean():.2f} EGP')
            plt.axvline(prices.median(), color='orange', linestyle='dashed', linewidth=2, label=f'Median: {prices.median():.2f} EGP')
            plt.title("Price Distribution of Pharmacy Products")
            plt.xlabel("Price (EGP)")
            plt.ylabel("Frequency")
            plt.legend()
            plt.tight_layout()
            p4 = os.path.join(out_dir, "plot_4_price_distribution_hist.png")
            plt.savefig(p4, dpi=200)
            plt.close()
            paths["hist_price_distribution"] = p4

    return paths


# =========================
# HTML REPORT
# =========================
def df_to_html_table(df: pd.DataFrame, float_fmt: str = "{:,.2f}") -> str:
    def _fmt(x):
        if isinstance(x, (float, np.floating)) and not np.isnan(x):
            return float_fmt.format(float(x))
        return x

    if df is None or len(df) == 0:
        return "<p><em>No data available for this section.</em></p>"
    return df.map(_fmt).to_html(index=False, escape=True)


def build_html_report(
    aggs: dict[str, pd.DataFrame],
    plot_paths: dict[str, str],
    out_dir: str,
) -> str:
    os.makedirs(out_dir, exist_ok=True)
    report_path = os.path.join(out_dir, "stakeholder_report.html")
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    kpis_html = df_to_html_table(aggs["kpis"])
    category_html = df_to_html_table(aggs["category_stats"].head(10))
    pack_unit_html = df_to_html_table(aggs["pack_unit_stats"])
    discount_html = df_to_html_table(aggs["discount_summary"])
    top_discounted_html = df_to_html_table(aggs["top_discounted"].head(15))

    def img_tag(p: str, caption: str) -> str:
        rel = os.path.basename(p)
        return f"""
        <figure style="margin:16px 0;">
          <img src="{rel}" style="max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 8px;">
          <figcaption style="color:#444; font-size: 14px; margin-top: 6px;">{caption}</figcaption>
        </figure>
        """

    plots_section = ""
    captions = {
        "bar_top_categories": "Bar chart: Top 10 categories by product count.",
        "bar_price_comparison": "Bar chart: Average price vs discounted price by category.",
        "pie_discount_distribution": "Pie chart: Products with vs without discount.",
        "hist_price_distribution": "Histogram: Price distribution of all products.",
    }
    for key, caption in captions.items():
        if key in plot_paths:
            plots_section += img_tag(plot_paths[key], caption)

    html = f"""
    <html>
    <head>
      <meta charset="utf-8"/>
      <title>Pharmacy Products Report</title>
      <style>
        body {{ font-family: Arial, sans-serif; margin: 24px; color: #111; }}
        h1, h2, h3 {{ margin-bottom: 8px; }}
        .meta {{ color: #555; margin-bottom: 18px; }}
        table {{ border-collapse: collapse; width: 100%; margin: 10px 0 22px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; font-size: 14px; }}
        th {{ background: #f5f5f5; text-align: left; }}
        .section {{ margin-top: 22px; }}
      </style>
    </head>
    <body>
      <h1>Pharmacy Products Analysis Report</h1>
      <div class="meta">Generated: {now}</div>

      <div class="section">
        <h2>1) Executive KPIs</h2>
        {kpis_html}
      </div>

      <div class="section">
        <h2>2) Top Categories (Product Count, Pricing, Discounts)</h2>
        {category_html}
      </div>

      <div class="section">
        <h2>3) Pack Unit Analysis</h2>
        {pack_unit_html}
      </div>

      <div class="section">
        <h2>4) Discount Analysis</h2>
        {discount_html}
        <h3>Top Discounted Products</h3>
        {top_discounted_html}
      </div>

      <div class="section">
        <h2>Visual Insights</h2>
        {plots_section if plots_section else "<p><em>No plots were generated (missing columns).</em></p>"}
      </div>
    </body>
    </html>
    """

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)

    return report_path


# =========================
# MAIN
# =========================
def main():
    args = parse_args()

    df = load_collection_as_df(args.mongo_uri, args.db_name, args.collection_name)
    df = coerce_types(df)

    aggs = build_aggregations(df)
    plot_paths = save_plots(aggs["df_for_plots"], aggs["category_stats"], aggs["pack_unit_stats"], args.out_dir)
    report_path = build_html_report(aggs, plot_paths, args.out_dir)

    print("Loaded rows:", df.shape[0], "cols:", df.shape[1])
    print("Saved HTML report:", report_path)
    if plot_paths:
        print("Saved plots:")
        for k, v in plot_paths.items():
            print(" -", k, "->", v)


if __name__ == "__main__":
    main()
