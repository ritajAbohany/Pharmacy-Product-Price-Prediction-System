/*****************************************************
 * Pharmacy Product Price Prediction System
 * Database: pharmacyDB
 * Collection: sales
 *****************************************************/

/***********************
 * USE DATABASE
 ***********************/
use pharmacyDB;


/***********************
 * VERIFY DATA
 ***********************/
db.sales.findOne();


/***********************
 * INDEXING
 ***********************/

// Drop existing indexes (for clean demo)
db.sales.dropIndexes();

// Create Index #1 (Single-field)
db.sales.createIndex({ name: 1 });

// Create Index #2 (Compound index)
db.sales.createIndex({ category: 1, price: -1 });


/***********************
 * EXPLAIN WITHOUT INDEX
 ***********************/
db.sales.dropIndexes();

db.sales.find({ name: "Paracetamol" })
  .explain("executionStats");


/***********************
 * EXPLAIN WITH INDEX
 ***********************/
db.sales.createIndex({ name: 1 });

db.sales.find({ name: "Paracetamol" })
  .explain("executionStats");


/***********************
 * AGGREGATION PIPELINES
 ***********************/

// Total discounted value per category
db.sales.aggregate([
  {
    $group: {
      _id: "$category",
      totalValue: { $sum: "$discounted_price" }
    }
  }
]);

// Average price per category
db.sales.aggregate([
  {
    $group: {
      _id: "$category",
      avgPrice: { $avg: "$price" }
    }
  }
]);

// Optional: Average price per unit per category
db.sales.aggregate([
  {
    $group: {
      _id: "$category",
      avgPricePerUnit: { $avg: "$price_per_unit" }
    }
  }
]);


/***********************
 * REPLICATION CHECK
 * (Run AFTER starting mongod with --replSet)
 ***********************/
rs.status();


/***********************
 * TRANSACTIONS (ACID)
 ***********************/

// Create stats collection
db.productStats.drop();
db.productStats.insertOne({ totalProducts: 0 });


/***********************
 * TRANSACTION COMMIT
 ***********************/
const sessionCommit = db.getMongo().startSession();
sessionCommit.startTransaction();

try {
  const salesCol = sessionCommit.getDatabase("pharmacyDB").sales;
  const statsCol = sessionCommit.getDatabase("pharmacyDB").productStats;

  salesCol.insertOne({
    name: "Test Vitamin C",
    packaging: "30 tablets",
    price: 25,
    discounted_price: 20,
    category: "Supplement",
    pack_quantity: 30,
    pack_unit: "tablet"
  });

  statsCol.updateOne({}, { $inc: { totalProducts: 1 } });

  sessionCommit.commitTransaction();
  print("Transaction committed successfully");

} catch (e) {
  sessionCommit.abortTransaction();
  print("Transaction aborted");
}

sessionCommit.endSession();


/***********************
 * TRANSACTION ROLLBACK
 ***********************/
const sessionRollback = db.getMongo().startSession();
sessionRollback.startTransaction();

try {
  const salesCol = sessionRollback.getDatabase("pharmacyDB").sales;
  const statsCol = sessionRollback.getDatabase("pharmacyDB").productStats;

  salesCol.insertOne({
    name: "Broken Transaction Drug",
    price: 10,
    category: "Test"
  });

  // Force an error
  statsCol.updateOne({}, { $inc: { totalProducts: "wrongType" } });

  sessionRollback.commitTransaction();

} catch (e) {
  sessionRollback.abortTransaction();
  print("Transaction rolled back");
}

sessionRollback.endSession();


/***********************
 * VERIFY ROLLBACK
 ***********************/
db.sales.find({ name: "Broken Transaction Drug" });
