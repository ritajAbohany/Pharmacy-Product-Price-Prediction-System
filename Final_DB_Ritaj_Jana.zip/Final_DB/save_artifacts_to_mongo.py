"""
save_artifacts_to_mongodb.py

Goal:
- Save cleaned CSV rows into a normal MongoDB collection named: data
- Save the joblib pipeline as a single document in a collection named: models
  (models will contain ONLY ONE document; we will upsert it with _id="active")

Notes:
- Dataset is stored as JSON documents (one doc per row) in `data`.
- Pipeline is stored as binary bytes in `models` using a BinData field.
- You paste your MongoDB URI yourself.

Usage:
  python save_artifacts_to_mongo.py --mongo_uri "mongodb+srv://finalprojectuser:2GlssgBVL0sB65uI@final-project-cluster.0kkgxgo.mongodb.net/?appName=final-project-cluster" \
    --joblib_path "discounted_price_rf_pipeline.joblib" \
    --csv_path "cleaned_pharmacy_data.csv" \
    --db "pharmacyDB"
"""
import argparse
import hashlib
import os
from datetime import datetime, timezone

import pandas as pd
from bson.binary import Binary
from pymongo import MongoClient
import gridfs


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mongo_uri", required=True, help="Paste your MongoDB URI here")
    ap.add_argument("--joblib_path", required=True, help="Path to saved pipeline joblib")
    ap.add_argument("--csv_path", required=True, help="Path to cleaned CSV")
    ap.add_argument("--db", default="ml_registry", help="MongoDB database name")
    ap.add_argument("--data_col", default="data", help="Collection name for dataset rows")
    ap.add_argument("--models_col", default="models", help="Collection name for pipeline doc")
    ap.add_argument("--drop_data", action="store_true", help="Drop `data` collection before inserting")
    ap.add_argument("--batch_size", type=int, default=5000, help="Insert batch size for dataset rows")
    args = ap.parse_args()

    # Validate inputs
    for p in (args.joblib_path, args.csv_path):
        if not os.path.isfile(p):
            raise FileNotFoundError(f"File not found: {p}")

    # Connect
    client = MongoClient(args.mongo_uri)
    db = client[args.db]
    data_col = db[args.data_col]
    models_col = db[args.models_col]

    utc_now = datetime.now(timezone.utc)

    # -----------------------------
    # 1) Save dataset into `data`
    # -----------------------------
    df = pd.read_csv(args.csv_path)

    # Convert NaN to None so MongoDB accepts them cleanly
    df = df.where(pd.notnull(df), None)

    # Optional: reset data collection
    if args.drop_data:
        data_col.drop()

    # Insert rows in batches
    records = df.to_dict(orient="records")
    total = len(records)

    if total > 0:
        for i in range(0, total, args.batch_size):
            batch = records[i : i + args.batch_size]
            data_col.insert_many(batch, ordered=False)

    # Dataset metadata (stored in the single models doc for convenience)
    dataset_meta = {
        "csv_path": os.path.abspath(args.csv_path),
        "rows_inserted": total,
        "cols": list(df.columns),
        "csv_sha256": sha256_file(args.csv_path),
        "saved_at": utc_now,
        "collection": args.data_col,
    }

    # ------------------------------------
    # 2) Save pipeline using GridFS (handles large files > 16MB)
    # ------------------------------------
    with open(args.joblib_path, "rb") as f:
        pipeline_bytes = f.read()

    pipeline_sha256 = sha256_bytes(pipeline_bytes)
    
    # Use GridFS to store large pipeline files
    fs = gridfs.GridFS(db, collection="model_files")
    
    # Delete any existing file with the same filename to allow "upsert" behavior
    existing = fs.find_one({"filename": "active_pipeline.joblib"})
    if existing:
        fs.delete(existing._id)
    
    # Store the pipeline in GridFS
    gridfs_id = fs.put(
        pipeline_bytes,
        filename="active_pipeline.joblib",
        content_type="application/octet-stream",
        type="sklearn_pipeline_joblib",
        original_filename=os.path.basename(args.joblib_path),
        joblib_path=os.path.abspath(args.joblib_path),
        sha256=pipeline_sha256,
        saved_at=utc_now,
    )

    # Store metadata document (without the binary artifact) in models collection
    model_doc = {
        "_id": "active",
        "type": "sklearn_pipeline_joblib",
        "filename": os.path.basename(args.joblib_path),
        "joblib_path": os.path.abspath(args.joblib_path),
        "size_bytes": len(pipeline_bytes),
        "sha256": pipeline_sha256,
        "gridfs_id": gridfs_id,  # Reference to GridFS file
        "gridfs_filename": "active_pipeline.joblib",
        "saved_at": utc_now,
        "dataset": dataset_meta,
    }

    models_col.replace_one({"_id": "active"}, model_doc, upsert=True)

    # Helpful indexes for aggregations/queries on data (optional but useful)
    # Add your own based on columns you group by often.
    # Example (uncomment if you have these columns):
    # data_col.create_index("job_category")
    # data_col.create_index("education_level")

    print("Done.")
    print(f"- Inserted {total} rows into {args.db}.{args.data_col}")
    print(f"- Upserted pipeline into {args.db}.{args.models_col} with _id='active'")
    print(f"- Pipeline stored in GridFS (model_files.files/chunks)")
    print(f"- Pipeline SHA256: {pipeline_sha256}")
    print(f"- CSV SHA256: {dataset_meta['csv_sha256']}")


if __name__ == "__main__":
    main()